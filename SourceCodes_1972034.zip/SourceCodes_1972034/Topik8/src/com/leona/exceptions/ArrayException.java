/**
 * @author Leona Rose (1972034)
 */

package com.leona.exceptions;

public class ArrayException extends Exception {
    public ArrayException(String message){
        super(message);
    }
}
