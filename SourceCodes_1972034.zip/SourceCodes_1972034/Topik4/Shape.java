/**
 * @author Leona Rose (1972034)
 */

 public abstract class Shape {
    public abstract double getArea();
}
